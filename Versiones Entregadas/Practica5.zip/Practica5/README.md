<h2 align='center'>
  Práctica 5: 
</h2>

<br>

### Alumnos

| Alumnos                     | No. de Cuenta |
| --------------------------- | ------------- |
| Paredes Zamudio Luis Daniel | 318159926     |
| Robledo Ramírez Isaac       | 320140655     |

<br>

### Funciones Auxiliares

Usamos dos funciones auxiliares. Una vista en clase llamada _"esLiteral"_ y otra llamada _"removeItem"_. 

La primera, como su nombre lo dice, es revisar si una formula dada es efecto una literal o no. 
Esto nos ayuda para que la función _"literales"_ sea mapeable a una lista de formulas. 

La segunda nos ayuda a remover un elemento de una lista de formulas, lo cual es útil en las funciones
_"expAlpha" y "expBeta"_, ya que debemos justamente remover elementos al querer expandir las formulas según 
el tipo que sean.  

### Extras

Utilizamos la sintaxis vista en clase de _"where"_ en algunos ejemplos, asi como como la idea detrás de _"map"_ y _"$"_
para la función _"literales"_.
<br>

> _So here we are again. It's always such a pleasure. Remember when you tried to kill me twice?_
