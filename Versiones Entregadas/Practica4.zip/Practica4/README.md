<h2 align='center'>
  Práctica 4: Lógica proposicional.
</h2>

<br>

### Alumnos

| Alumnos                     | No. de Cuenta |
| --------------------------- | ------------- |
| Paredes Zamudio Luis Daniel | 318159926     |
| Robledo Ramírez Isaac       | 320140655     |

<br>

### Funciones Auxiliares

Usamos tres funciones auxiliares para _"vars"_. 
- _Ordena_: Ordena los elementos de una propisición
- _noDouble_: Quita duplicados de una proposición
- _takeS_: Obtiene un elemento de la cadena (en si, de una lista, pero que es un String si no una cadena de Chars?)

<br>

Para la función de _"interpreta"_, usamos una función auxiliar a la que llamamos _"asignaValor"_. La lógica detras de ella es que como podemos recibir varias variables en una asignación, ésta función detecta a que letra corresponde cada valor de la asignación. Asi, la usamos para poder
usarla como caso base en el resto de la función _"interpreta"_.  


### Extras

<br>

> _So you make a neat gun, think of all the things we've learned from the people who are still alive..._
