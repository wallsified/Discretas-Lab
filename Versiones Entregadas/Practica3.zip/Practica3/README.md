<h2 align='center'>
  Práctica 3: Listas de longitud par. 
</h2>

<br>

### Alumnos

| Alumnos                     | No. de Cuenta |
| --------------------------- | ------------- |
| Paredes Zamudio Luis Daniel | 318159926     |
| Robledo Ramírez Isaac       | 320140655     |

<br>

### Funciones Auxiliares

Volvimos a ocupar myMod para implementar el funcionamiento de la función nativa de Haskell _mod_.

<br>

### Extras

No hubo funciones extras para esta práctica 

<br>

> _You just keep on trying 'till you run out of cake..._
